module Materialize
  module Sass
    VERSION = "0.97.7"
  end
end

