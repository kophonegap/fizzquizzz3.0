var base_url2 ='http://ec2-54-191-6-205.us-west-2.compute.amazonaws.com/fizzquizzserver/admins';
